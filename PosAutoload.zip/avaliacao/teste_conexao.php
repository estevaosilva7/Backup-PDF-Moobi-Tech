<?php
$config = require 'config/configuracoes.php';
require '../avaliacao/app/Database/MoobiDatabaseHandler.php';


try {
    $database = new MoobiDatabaseHandler($config);
    $connection = $database->getConexao();

    if ($connection) {
        echo "Conexã bem-sucedida ao banco de dados!";
    }
} catch (Exception $e) {
    echo "Erro na conexão : " . $e->getMessage();
}
