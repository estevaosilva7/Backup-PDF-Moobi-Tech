<?php
spl_autoload_register(function ($classe) {

    $diretorios = [
        'app/Libraries/',
        'app/Database',
    ];

    foreach ($diretorios as $diretorio):
        $caminho = __DIR__ . DIRECTORY_SEPARATOR . $diretorio . DIRECTORY_SEPARATOR . $classe . '.php';
        if (file_exists($caminho)):
            require_once $caminho;
        endif;
    endforeach;
});
