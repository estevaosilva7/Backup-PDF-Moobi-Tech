<footer class="bg-dark p-5 text-light">
    <div class="container">
        <small>
            <?php echo APP_NOME . ' ' . APP_VERSAO; ?>
            <div class="border-top mt-3">
                &COPY; 2024 - <?php echo date('Y'); ?>
            </div>
        </small>
    </div>
</footer>