<h1><?php echo $dados['tituloPagina']; ?></h1>

<?php echo APP_VERSAO; ?>