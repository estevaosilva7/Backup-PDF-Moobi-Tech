<?php

class Posts
{

}