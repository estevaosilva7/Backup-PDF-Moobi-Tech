<?php
class Usuarios extends Controller {
    public function cadastrar() {

        $this->view('usuarios/cadastrar');

    }
}