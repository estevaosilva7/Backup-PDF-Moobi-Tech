<?php
require_once __DIR__ . '/../Database/MoobiDatabaseHandler.php';
require_once __DIR__ . '/../Models/DependenteModel.php';
require_once __DIR__ . '/../Session/CustomSessionHandler.php';
require_once __DIR__ . '/../Configuracoes/Url_Local.php';

/**
 * Controlador responsável pelas operações relacionadas aos dependentes de um filiado.
 * Permite cadastrar, listar, editar e deletar dependentes. Somente administradores têm
 * permissão para realizar essas operações.
 *
 * @author Estevão carlosestevao@moobitech.com.br
 */

class DependenteController
{
    private $dependenteModel;

    /**
     * Construtor da classe DependenteController.
     * Inicializa o modelo DependenteModel com a conexão PDO.
     *
     * @param $dbHandler Instância da classe MoobiDatabaseHandler.
     */
    public function __construct()
    {
        $dbHandler = new MoobiDatabaseHandler();
        $this->dependenteModel = new DependenteModel($dbHandler);
    }

    /**
     * Cadastra um dependente para um filiado.
     * Realiza validação e cadastro de dados recebidos do formulário.
     *
     * @param int $filiadoId ID do filiado.
     */
    public function cadastrar(array $aDados = null)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem cadastrar dependentes.</p>";
            return header("Location: /index.php/filiado/listar");
        }

        $aDados = $aDados ?: $_POST;

        if ($aDados) {
            $nome = $aDados['nome'] ?? null;;
            $dataNascimento = $aDados['dataNascimento'] ?? null;;
            $grauParentesco = $aDados['grauParentesco'] ?? null;;
            $filiadoId = $aDados['filiadoId'] ?? null;;


            if (empty($filiadoId) || !is_numeric($filiadoId)) {
                die("Erro: O ID do filiado é inválido.");
            }

            $this->dependenteModel->cadastrarDependente($nome, $dataNascimento, $grauParentesco, $filiadoId);
            header('Location: ' . Config::pegarUrl() . 'dependente/listar&id=' . $filiadoId);
            exit();

        }
        $aDados = $aDados ?: $_GET;

        $filiadoId = $aDados['filiadoId'] ?? null;

        if (!$filiadoId) {
            die("Erro: ID do filiado não fornecido.");
        }
        require_once __DIR__ . '/../Views/Dependente/CadastrarDependenteView.php';
    }

    /**
     * Lista os dependentes de um filiado.
     * Exibe todos os dependentes associados ao filiado com o ID fornecido.
     *
     * @param int $filiadoId ID do filiado.
     */
    public function listar($filiadoId)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        $isAdmin = ($usuarioLogado && $usuarioLogado['usu_Tipo'] == 'admin');

        $dependentes = $this->dependenteModel->listarPorFiliado($filiadoId);

        require_once __DIR__ . '/../Views/Dependente/ListarDependenteView.php';
    }

    /**
     * Edita os dados de um dependente.
     * Atualiza as informações do dependente com os dados fornecidos no formulário.
     *
     * @param int $id ID do dependente.
     */
    public function editar(int $id, array $aDados = null)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem editar dependentes.</p>";
            return header("Location: /index.php?path=filiado/listar");
        }
        $aDados = $aDados ?: $_POST;
        if ($aDados) {
            $nome = $aDados['nome'] ?? null;
            $dataNascimento = $aDados['dataNascimento'] ?? null;
            $grauParentesco = $aDados['grauParentesco'] ?? null;
            $filiadoId = $aDados['filiadoId'] ?? null;

            $this->dependenteModel->editarDependente($id, $nome, $dataNascimento, $grauParentesco);

            header('Location: ' . Config::pegarUrl() . "dependente/listar&id={$filiadoId}" );
        }

        $dependente = $this->dependenteModel->buscarPorId($id);

        if (!$dependente) {
            die("Erro: Dependente não encontrado.");
        }
        require_once __DIR__ . '/../Views/Dependente/EditarDependenteView.php';
    }

    /**
     * Exclui um dependente do sistema.
     * Remove o dependente do banco de dados e redireciona para a lista de dependentes.
     *
     * @param int $id ID do dependente.
     * @param int $filiadoId ID do filiado ao qual o dependente pertence.
     */
    public function deletar($id, array $aDados)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem excluir dependentes.</p>";
            return header("Location: /index.php?path=filiado/listar");
        }
        $filiadoId = $aDados['filiadoId'];

        $this->dependenteModel->deletarDependente($id);

        header('Location: ' . Config::pegarUrl() . 'dependente/listar&id='. $filiadoId);

    }
}
