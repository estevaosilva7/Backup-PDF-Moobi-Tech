<?php
require_once __DIR__ . '/../Database/MoobiDatabaseHandler.php';
require_once __DIR__ . '/../Models/FiliadoModel.php';
require_once __DIR__ . '/../Session/CustomSessionHandler.php';
require_once __DIR__ . '/../Configuracoes/Url_Local.php';

/**
 * Controlador para gerenciar as ações relacionadas aos filiados.
 * Contém métodos para  cadastro, listagem, exclusão, edição, atualização de filiados e verificação da existência de dependentes por filiado.
 *
 * @author Estevão carlosestevao@moobitech.com.br
 */

class FiliadoController
{
    private $filiadoModel;

    /**
     * Construtor da classe FiliadoController.
     * Inicializa a instância do modelo de filiado com a conexão do banco de dados.
     *
     * @param $dbHandler Instância da classe MoobiDatabaseHandler.
     */
    public function __construct()
    {
        $dbHandler = new MoobiDatabaseHandler();
        $this->filiadoModel = new FiliadoModel($dbHandler);
    }

    /**
     * Exibe a tela de cadastro de filiado e processa o formulário de cadastro.
     * Valida e cadastra um novo filiado no sistema se os dados forem válidos.
     * Caso contrário, exibe mensagens de erro.
     *
     */
    public function cadastrar(array $aDados = null)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem cadastrar filiados.</p>";
            return require __DIR__ . '/../Views/Home/DashboardView.php';
        }
       $aDados = $aDados ?: $_POST;
        var_dump($aDados);

        if ($aDados) {
            var_dump($aDados);
            $mNome = $aDados['nome'] ?? null;
            $mCpf = $aDados['cpf'] ?? null;
            $mRg = $aDados['rg'] ?? null;
            $mDataNascimento = $aDados['dataNascimento'] ?? null;
            $mIdade = $aDados['idade'] ?? null;
            $mEmpresa = $aDados['empresa'] ?? null;
            $mCargo = $aDados['cargo'] ?? null;
            $mSituacao = $aDados['situacao'] ?? null;
            $mTelefoneResidencial = $aDados['telefoneResidencial'] ?? null;
            $mCelular = $aDados['celular'] ?? null;

            var_dump($mNome, $mCpf, $mRg, $mDataNascimento, $mIdade, $mEmpresa, $mCargo, $mSituacao, $mTelefoneResidencial, $mCelular);

            if ($this->filiadoModel->cadastrarFiliado($mNome, $mCpf, $mRg, $mDataNascimento, $mIdade, $mEmpresa, $mCargo, $mSituacao, $mTelefoneResidencial, $mCelular)) {
                $_SESSION['mensagem_sucesso'] = 'Filiado cadastrado com sucesso!';
                header('Location: ' . Config::pegarUrl() . 'filiado/listar');
            } else {
                $_SESSION['mensagem_erro'] = 'Erro ao cadastrar filiado';
                return require __DIR__ . '/../Views/Filiado/CadastrarFiliadoView.php';
            }
        } else {
            require __DIR__ . '/../Views/Filiado/CadastrarFiliadoView.php';
        }
    }



    /**
     * Lista todos os filiados cadastrados no sistema.
     * Exibe as informações dos filiados na view de listagem.
     */
    public function listar()
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        $filiados = $this->filiadoModel->listarFiliados();
        $isAdmin = ($usuarioLogado && $usuarioLogado['usu_Tipo'] == 'admin');

        require __DIR__ . '/../Views/Filiado/ListarFiliadoView.php';
    }

    /**
     * Exibe a tela de edição de filiado, carregando os dados do filiado pelo ID.
     * Caso o filiado não seja encontrado, exibe mensagem de erro e redireciona para a listagem.
     *
     * @param int $id ID do filiado a ser editado.
     */
    public function editar(int $id)
    {
        $filiado = $this->filiadoModel->buscarFiliadoPorId($id);
        if ($filiado) {
            require __DIR__ . '/../Views/Filiado/EditarFiliadoView.php';
            exit();
        } else {
            $_SESSION['mensagem_erro'] = 'Filiado não encontrado';
            header("Location: /index.php?path=filiado/listar");
            exit();
        }
    }

    /**
     * Atualiza as informações de um filiado no sistema.
     * Realiza a verificação de dados e atualiza as informações do filiado, redirecionando para a edição ou exibindo erro.
     *
     * @param int $id ID do filiado a ser atualizado.
     * @param array $aDados Dados atualizados do filiado (empresa, cargo, situação).
     */
    public function atualizar(int $id, array $aDados)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem editar filiados.</p>";
            header('Location: /index.php?path=filiado/listar');
            exit();
        }

        if ($aDados) {
            $empresa = $aDados['empresa'] ?? null;
            $cargo = $aDados['cargo'] ?? null;
            $situacao = $aDados['situacao'] ?? null;

            if ($this->filiadoModel->atualizarFiliado($id, $empresa, $cargo, $situacao)) {
                $_SESSION['mensagem_sucesso'] = 'Filiado atualizado com sucesso!';
                header('Location: ' . Config::pegarUrl() . "filiado/editar&id=$id");
            } else {
                $_SESSION['mensagem_erro'] = 'Erro ao atualizar filiado';
                header("Location: /index.php?path=filiado/editar&id=$id");
            }
        }
    }

    /**
     * Realiza a exclusão de um filiado do sistema, dado o ID.
     * Exibe mensagem de sucesso ou erro conforme o resultado da exclusão.
     *
     * @param int $id ID do filiado a ser deletado.
     */
    public function deletar(int $id)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem excluir filiados.</p>";
            header('Location: /index.php?path=filiado/listar');
            exit();
        }
        if (!isset($id) || !is_numeric($id)) {
            $_SESSION['mensagem_erro'] = 'ID inválido';
            header("Location: /index.php?path=filiado/listar");
            exit();
        }
        if ($this->filiadoModel->deletarFiliado($id)) {
            header('Location: ' . Config::pegarUrl() . 'filiado/listar');
        } else {
            $_SESSION['mensagem_erro'] = 'Erro ao deletar filiado';
            header("Location: /index.php?path=filiado/listar");
            exit();
        }
    }

    /**
     * Exibe a lista de dependentes de um filiado.
     * Caso não existam dependentes, exibe mensagem informando a ausência de dependentes para o filiado.
     *
     * @param int $filiadoId ID do filiado cujos dependentes serão listados.
     */
    public function dependentes(int $filiadoId)
    {
        $dependentes = $this->dependenteModel->listarPorFiliado($filiadoId);

        if (empty($dependentes)) {
            $mensagem = "Não existem dependentes para este filiado.";
        } else {
            $mensagem = "";
        }
        include 'Views/Dependente/DependenteListarView.php';
    }
}
?>
