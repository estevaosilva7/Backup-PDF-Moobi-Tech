<?php
spl_autoload_register(function ($class) {
    $SFile = __DIR__ . "/app/Controllers/$class.php";
    if (file_exists($SFile)) {
        include $SFile;
    } else {
        throw new Exception("Classe '$class' não encontrada.");
    }
});

$aDados = array_merge($_GET, $_POST);

$sPath = isset($aDados['path']) ? explode('/', $aDados['path']) : ['usuario', 'index'];

$sControllerName = ucfirst($sPath[0]) . 'Controller';
$sMetodo = $sPath[1] ?? 'index';

//$mId = $aDados['id'] ?? null;

try {
    if (class_exists($sControllerName)) {
        $oController = new $sControllerName();
    } else {
        throw new Exception("Controlador '$sControllerName' não encontrado.");
    }
    if (method_exists($oController, $sMetodo)) {
        $oController->$sMetodo($aDados); // Passa os dados que podem ser úteis.
    } else {
        throw new Exception("Método '$sMetodo' não encontrado no controlador '$sControllerName'.");
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage();
}
die();

