<?php

// Define a constante RAIZ como o diretório atual do arquivo
define('RAIZ', dirname(dirname(__FILE__)));

// Define a constante URL com a URL base da aplicação
define('URL', 'http://localhost:8080/avaliacao');

// Define a constante APP_NOME com o nome da aplicação
define('APP_NOME', 'Sindicato de Estágios');

// Define uma constante de versão da aplicação
const APP_VERSAO = '1.0.0.';
