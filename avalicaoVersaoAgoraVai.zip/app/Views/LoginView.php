<?php
require '../Database/MoobiDatabaseHandler.php';

session_start(); // Inicia a sessão

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mEmail = $_POST['email'];
    $mSenha = $_POST['senha'];

    // Cria a instância da classe para obter a conexão PDO
    $db = new MoobiDatabaseHandler();
    $pdo = $db->getConnection(); // Obtém a conexão do banco de dados

    // Prepara a consulta para verificar se o email existe
    $bStatement = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $bStatement->execute([$mEmail]);
    $mUsuario = $bStatement->fetch(PDO::FETCH_ASSOC);

    // Verifica se o usuário foi encontrado e se a senha é válida
    if ($mUsuario && password_verify($mSenha, $mUsuario['senha'])) {
        // Se o login for bem-sucedido, salva os dados do usuário na sessão
        $_SESSION['usuario'] = [
            'id' => $mUsuario['id'],
            'nome' => $mUsuario['nome'],
            'perfil' => $mUsuario['perfil'],
            'email' => $mUsuario['email']
        ];
        // Redireciona para a página do Dashboard
        header('Location: DashboardView.php');
        exit();
    } else {
        // Caso contrário, exibe mensagem de erro
        echo "E-mail ou senha incorretos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
<h1>Login</h1>

<!-- Formulário de login -->
<form method="POST" action="">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <button type="submit">Login</button>
</form>

</body>
</html>
