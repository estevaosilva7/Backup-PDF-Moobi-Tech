<?php
session_start();

function verificarLogin() {
    if (!isset($_SESSION['usuario'])) {
        header('Location: Views/LoginView.php');
        exit();
    }
}

function verificarAdmin() {
    return isset($_SESSION['usuario']) && $_SESSION['usuario']['tipo'] === 'admin';
}
