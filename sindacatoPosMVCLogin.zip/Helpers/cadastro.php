<?php
require '../Helpers/gestão_funcoes.php';
require '../app/Database/MoobiDatabaseHandler.php';
$MoobiDatabaseHandler = new MoobiDatabaseHandler();
verificarLogin();

if (!verificarAdmin()) {
    echo "Acesso negado!";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mNome = $_POST['nome'];
    $mSenha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $mTipo = $_POST['tipo'];


    $bStatement = $MoobiDatabaseHandler->getConnection()->prepare("INSERT INTO usuarios (usu_Nome, usu_Senha, usu_Tipo) VALUES (?, ?, ?)");
    $bStatement->execute([$mNome, $mSenha, $mTipo]);

    echo "Usuário cadastrado com sucesso!";
}
?>

<form method="POST" action="">
    <input type="text" name="nome" placeholder="Nome" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <select name="tipo">
        <option value="comum">Comum</option>
        <option value="admin">Admin</option>
    </select>
    <button type="submit">Cadastrar</button>
</form>

