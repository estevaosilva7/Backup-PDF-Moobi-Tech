<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está logado, se não, redireciona para a página de login
function verificarLogin() {
    if (!isset($_SESSION['usuario'])) {
        header('Location: Views/LoginView.php');
        exit();
    }
}

// Chama a função de verificação de login
verificarLogin();

// Exibe as informações do usuário logado
echo "Bem-vindo, " . $_SESSION['usuario']['nome'] . "!<br>";
echo "Perfil: " . $_SESSION['usuario']['tipo'] . "<br>";
?>

<a href="/Helpers/cadastro.php">Cadastrar Usuários</a><br>
<a href="/Helpers/lista_usuarios.php">Listar Usuários</a><br>
<a href="/Helpers/logout.php">Logout</a><br>
