<?php

class LoginModel
{
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function verificarUsuario($nome, $senha)
    {
        $statement = $this->pdo->prepare("SELECT * FROM usuarios WHERE usu_Nome = ?");
        $statement->execute([$nome]);
        $usuario = $statement->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($senha, $usuario['usu_Senha'])) {
            return $usuario;
        }

        return null;
    }
}
