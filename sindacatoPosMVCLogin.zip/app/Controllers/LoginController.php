<?php
require_once '../Database/MoobiDatabaseHandler.php';
require_once '../Models/LoginModel.php';
require_once '../Views/LoginView.php';
$controller = new LoginController();
$error = $controller->login();
class LoginController
{
    private $model;

    public function __construct()
    {
        $db = new MoobiDatabaseHandler();
        $pdo = $db->getConnection();
        $this->model = new LoginModel($pdo);
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $mNome = trim($_POST['nome']);
            $mSenha = $_POST['senha'];

            $mUsuario = $this->model->verificarUsuario($mNome, $mSenha);

            if ($mUsuario) {
                session_start();
                $_SESSION['usuario'] = [
                    'id' => $mUsuario['usu_Id'],
                    'nome' => $mUsuario['usu_Nome'],
                    'tipo' => $mUsuario['usu_Tipo'],
                ];

                header('Location: ../Views/DashboardView.php');
                exit();
            } else {
                return "Nome ou senha incorretos!";
            }
        }
    }
}

