<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Plataforma de Estagiários - Sindicato</title>
    <link rel="stylesheet" href="public/css/estilos.css">
</head>
<body>
<header>
    <h1>Bem-vindo à Plataforma do Sindicato dos Estagiários</h1>
    <nav>
        <ul>
            <li><a href="app/Views/LoginView.php">Faça seu Login aqui!</a></li>
        </ul>
    </nav>
</header>

<footer>
    <p>&copy; 2024 Sindicato dos Estagiários. Todos os direitos reservados.</p>
</footer>
</body>
</html>
