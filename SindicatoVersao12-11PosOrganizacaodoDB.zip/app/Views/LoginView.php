<?php
require '../Database/MoobiDatabaseHandler.php';

session_start(); // Inicia a sessão

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mNome = $_POST['nome'];
    $mSenha = $_POST['senha'];

    // Cria a instância da classe para obter a conexão PDO
    $db = new MoobiDatabaseHandler();
    $pdo = $db->getConnection(); // Obtém a conexão do banco de dados

    // Prepara a consulta para verificar se o nome de usuário existe
    $bStatement = $pdo->prepare("SELECT * FROM usuarios WHERE usu_Nome = ?");
    $bStatement->execute([$mNome]);
    $mUsuario = $bStatement->fetch(PDO::FETCH_ASSOC);

    // Verifica se o usuário foi encontrado e se a senha é válida
    if ($mUsuario && password_verify($mSenha, $mUsuario['usu_Senha'])) {
        $_SESSION['usuario'] = [
            'id' => $mUsuario['usu_Id'],
            'nome' => $mUsuario['usu_Nome'],
            'tipo' => $mUsuario['usu_Tipo'],
        ];
        header('Location: DashboardView.php');
        exit();
    } else {
        echo "Nome ou senha incorretos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
<h1>Login</h1>

<form method="POST" action="">
    <input type="text" name="nome" placeholder="Nome" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <button type="submit">Login</button>
</form>

</body>
</html>
