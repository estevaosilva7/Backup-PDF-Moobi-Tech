<?php

$senha = "";
$senhaHash = password_hash($senha, PASSWORD_BCRYPT);
echo $senhaHash;
