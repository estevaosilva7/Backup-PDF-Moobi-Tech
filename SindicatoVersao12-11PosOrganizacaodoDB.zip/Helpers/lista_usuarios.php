<?php
require '../Helpers/gestão_funcoes.php';
require '../app/Database/MoobiDatabaseHandler.php';  // Certifique-se de incluir a classe de conexão

// Verificar o login (certifique-se de que a função 'verificarLogin' está funcionando corretamente)
verificarLogin();

// Instanciar a classe MoobiDatabaseHandler para obter a conexão com o banco
try {
    $db = new MoobiDatabaseHandler();
    $pdo = $db->getConnection();  // Obter a conexão do banco de dados
} catch (Exception $e) {
    die("Erro ao conectar com o banco de dados: " . $e->getMessage());
}

// Executar a consulta para pegar os usuários
try {
    $bStatement = $pdo->query("SELECT usu_Nome, usu_Tipo FROM usuarios");

    // Verificar se há resultados
    if ($bStatement->rowCount() > 0) {
        echo "<h1>Lista de Usuários</h1>";  // Fechar a tag <h1> corretamente

        // Loop para exibir os dados dos usuários
        while ($mUsuario = $bStatement->fetch(PDO::FETCH_ASSOC)) {
            echo "Nome: {$mUsuario['usu_Nome']} - Tipo: {$mUsuario['usu_Tipo']}<br>";
        }
    } else {
        echo "Nenhum usuário encontrado.";
    }
} catch (PDOException $e) {
    echo "Erro na consulta: " . $e->getMessage();
}
?>
