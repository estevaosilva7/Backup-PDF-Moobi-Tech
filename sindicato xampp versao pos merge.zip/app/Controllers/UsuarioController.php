<?php
require_once __DIR__ . '/../Database/MoobiDatabaseHandler.php';
require_once __DIR__ . '/../Models/UsuarioModel.php';
require_once __DIR__ . '/../Session/CustomSessionHandler.php';
require_once __DIR__ . '/../Configuracoes/Url_Local.php';

/**
 * Controlador para gerenciar as ações relacionadas aos usuários.
 * Contém métodos para login, cadastro, listagem, exclusão. edição, atualização e logout de usuários.
 *
 * @author Estevão carlosestevao@moobitech.com.br
 */
class UsuarioController
{
	private $usuarioModel;

	/**
	 * Construtor da classe UsuarioController.
	 * Inicializa a instância do modelo de usuário com a conexão do banco de dados.
	 *
	 * @param $dbHandler Instância da classe MoobiDatabaseHandler.
	 */
	public function __construct()
	{
		$dbHandler = new MoobiDatabaseHandler();
		$this->usuarioModel = new UsuarioModel($dbHandler);

	}

	/**
	 * Exibe a tela inicial de login.
	 */
	public function index(): void
	{
		require __DIR__ . '/../Views/Home/LoginView.php';
	}

	/**
	 * Exibe a tela do dashboard para o usuário autenticado.
	 */
	public function dashboard(): void
	{
		require __DIR__ . '/../Views/Home/DashboardView.php';
	}

	/**
	 * Realiza o login do usuário, validando o nome de usuário e senha.
	 * Caso o login seja bem-sucedido, inicia uma sessão e redireciona para o dashboard.
	 *
	 * @param array|null $aDados Dados de login do usuário (nome e senha).
	 * @return void
	 */
	public function login(?array $aDados = null): void
	{
		$mNome = $aDados['nome'] ?? null;
		$sSenha = $aDados['senha'] ?? null;

		if ($mNome && $sSenha) {
			$nUsuario = $this->usuarioModel->verificarUsuario($mNome, $sSenha);

			if ($nUsuario) {
				CustomSessionHandler::set('usuario', $nUsuario);
				require __DIR__ . '/../Views/Home/DashboardView.php';
				exit();
			} else {
				echo "<p>Nome ou senha incorretos!</p>";
			}
		}
		$this->index();
	}

	/**
	 * Realiza o cadastro de um novo usuário no sistema.
	 * Verifica se os dados são válidos e tenta salvar o novo usuário no banco.
	 *
	 * @param array $aDados Dados do novo usuário a ser cadastrado (nome, senha e tipo).
	 */
	public function cadastrar(?array $aDados = null): void
	{
		$usuarioLogado = CustomSessionHandler::get('usuario');
		if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
			echo "<p>Acesso restrito. Somente administradores podem cadastrar usuários.</p>";
			require __DIR__ . '/../Views/Home/DashboardView.php';
			exit();
		}
		if (isset($aDados['cadastro'])) {
			$mNome = $aDados['nome'] ?? null;
			$sSenha = $aDados['senha'] ?? null;
			$mTipo = $aDados['tipo'] ?? null;

			if (!preg_match('/^(?=.*[a-zA-Z])[a-zA-Z0-9]+$/', $mNome)) {
				echo "<p>O nome de usuário deve conter pelo menos uma letra e pode incluir apenas letras e números.</p>";
				require __DIR__ . '/../Views/Usuario/CadastroUsuarioView.php';
			}

			if ($this->usuarioModel->cadastrarUsuario($mNome, $sSenha, $mTipo)) {
				echo "<p>Usuário cadastrado com sucesso!</p>";
			} else {
				echo "<p>ALERTA: Nome de usuário já em uso!</p>";
			}
		}
		require __DIR__ . '/../Views/Usuario/CadastroUsuarioView.php';
		exit();
	}

	/**
	 * Lista todos os usuários cadastrados no sistema.
	 * Exibe as informações dos usuários na view de listagem.
	 *
	 * @return void
	 */
	public function listar(): void
	{
		$usuarios = $this->usuarioModel->listarUsuarios();
		$usuarioLogado = CustomSessionHandler::get('usuario');
		$isAdmin = $usuarioLogado && $usuarioLogado['usu_Tipo'] == 'admin';

		require __DIR__ . '/../Views/Usuario/ListarUsuarioView.php';
		exit();
	}

	/**
	 * Realiza a exclusão de um usuário do sistema, dado o ID.
	 * Exibe mensagem de sucesso ou erro conforme o resultado da exclusão.
	 *
	 * @param int $iId ID do usuário a ser deletado.
	 * @return void
	 */
	public function deletar(?array $aDados = null): void
	{
		$usuarioLogado = CustomSessionHandler::get('usuario');
		if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
			echo "<p>Acesso restrito. Somente administradores podem excluir usuários.</p>";
			header('Location: /index.php/usuario/listar');
			exit();
		}
		if ($aDados['id'] && is_numeric($aDados['id'])) {
			$bResultado = $this->usuarioModel->deletarUsuario($aDados['id']);
			if ($bResultado) {
				echo "<p>Usuário deletado com sucesso!</p>";
			} else {
				echo "<p>Erro ao deletar o usuário!</p>";
			}
		} else {
			echo "<p>ID inválido!</p>";
		}
		header('Location: ' . Config::pegarUrl() . 'usuario/listar');
		exit();
	}

	/**
	 * Exibe o formulário de edição de usuário.
	 * Realiza a verificação do ID e exibe as informações do usuário para edição.
	 *
	 * @param int $id ID do usuário a ser editado.
	 * @return void
	 */
	public function editar(?array $aDados = null): void
	{
		$usuarioLogado = CustomSessionHandler::get('usuario');
		if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
			echo "<p>Acesso restrito. Somente administradores podem editar usuários.</p>";
			header('Location: /index.php?path=usuario/listar');
			exit();
		}
		if ($aDados['id'] && is_numeric($aDados['id'])) {
			$usuario = $this->usuarioModel->buscarUsuarioPorId($aDados['id']);
			if (!$usuario) {
				echo "<p>Usuário não encontrado!</p>";
				header('Location: /index.php?path=usuario/listar');
				exit();
			}
			require __DIR__ . '/../Views/Usuario/EditarUsuarioView.php';

		} else {
			echo "<p>ID inválido!</p>";
			header('Location: /index.php?path=usuario/listar');
			exit();
		}
	}

	/**
	 * Atualiza os dados de um usuário no sistema.
	 * Verifica se o novo nome de usuário já existe e valida os dados antes de realizar a atualização.
	 *
	 * @param int $id ID do usuário a ser atualizado.
	 * @param array $aDados Dados atualizados do usuário (nome, tipo).
	 * @return void
	 */
	public function atualizar(?array $aDados = null): void
	{
		$id = $aDados['id'];
		$usuarioLogado = CustomSessionHandler::get('usuario');
		if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
			echo "<p>Acesso restrito. Somente administradores podem editar usuários.</p>";
			header('Location: /index.php/usuario/listar');
			exit();
		}
		if ($id && is_numeric($id)) {
			$mNome = $aDados['nome'] ?? null;
			$mTipo = $aDados['tipo'] ?? null;

			if ($this->usuarioModel->usuarioNomeExistente($mNome, $id)) {
				CustomSessionHandler::set('mensagem_erro', "O nome de usuário já está em uso.");
				header("Location: /index.php/usuario/editar&id=$id");
				exit();
			}
			if (!preg_match('/^(?=.*[a-zA-Z])[a-zA-Z0-9]+$/', $mNome)) {
				CustomSessionHandler::set('mensagem_erro', "O nome de usuário deve conter pelo menos uma letra e pode incluir apenas letras e números.");
				header("Location: /index.php/usuario/editar&id=$id");
				exit();
			}
			if ($this->usuarioModel->atualizarUsuario($id, $mNome, $mTipo)) {
				CustomSessionHandler::set('mensagem_sucesso', "Usuário atualizado com sucesso!");
				header('Location: ' . Config::pegarUrl() . "usuario/editar&id=$id");
				exit();
			} else {
				CustomSessionHandler::set('mensagem_erro', "Erro ao atualizar o usuário!");
				header("Location: /index.php/usuario/editar&id=$id");
				exit();
			}
		} else {
			CustomSessionHandler::set('mensagem_erro', "ID inválido!");
			header('Location: /index.php/usuario/listar');
			exit();
		}
	}

	/**
	 * Realiza o logout do usuário, destruindo a sessão.
	 * Redireciona o usuário para a página inicial.
	 *
	 * @return void
	 */
	public function logout(): void
	{
		CustomSessionHandler::destroy();
		header('Location: ' . Config::pegarUrl() . 'usuario/login');
		exit();
	}
}
?>
