<?php

class Valicacoes
{
	public static function validarUsuario(string $username): void {
		try {
			if (!preg_match('/^(?=.*[a-zA-Z])[a-zA-Z0-9]+$/', $username)) {
				throw new Exception("O nome de usuário deve conter pelo menos uma letra e pode incluir apenas letras e números.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarNomePessoal(string $name): void {
		try {
			if (!preg_match('/^[a-zA-ZÀ-ÿ\s]+$/', $name)) {
				throw new Exception("O nome pessoal deve conter apenas letras.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarCPF(string $cpf): void {
		try {
			$cpf = preg_replace('/\D/', '', $cpf); // Remove caracteres não numéricos

			if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) {
				throw new Exception("O CPF deve conter exatamente 11 dígitos válidos.");
			}

			// Validação do dígito verificador
			for ($t = 9; $t < 11; $t++) {
				$d = 0;
				for ($c = 0; $c < $t; $c++) {
					$d += $cpf[$c] * (($t + 1) - $c);
				}
				$d = ((10 * $d) % 11) % 10;
				if ($cpf[$c] != $d) {
					throw new Exception("O CPF é inválido.");
				}
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarRG(string $rg): void {
		try {
			if (!preg_match('/^\d{10}$/', $rg)) {
				throw new Exception("O RG deve conter exatamente 10 dígitos.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarDataNascimento(string $birthdate): void {
		try {
			$date = DateTime::createFromFormat('Y-m-d', $birthdate);
			if (!$date || $date->format('Y-m-d') !== $birthdate) {
				throw new Exception("A data de nascimento deve estar no formato YYYY-MM-DD.");
			}

			$today = new DateTime();
			$age = $today->diff($date)->y;

			if ($age < 18) {
				throw new Exception("A pessoa deve ter pelo menos 18 anos.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarIdade(int $age): void {
		try {
			if ($age < 18) {
				throw new Exception("A idade deve ser maior ou igual a 18 anos.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarCargoEmpresa(string $input): void {
		try {
			if (!preg_match('/^[a-zA-Z0-9\s]+$/', $input)) {
				throw new Exception("O campo de cargo e empresa deve conter apenas letras e números.");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarTelefoneFixo(string $landline): void {
		try {
			if (!preg_match('/^\d{10}$/', $landline)) {
				throw new Exception("O telefone fixo deve conter exatamente 10 dígitos (incluindo DDD).");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}

	public static function validarTelefoneCelular(string $mobile): void {
		try {
			if (!preg_match('/^\d{11}$/', $mobile)) {
				throw new Exception("O telefone celular deve conter exatamente 11 dígitos (incluindo DDD).");
			}
		} catch (Exception $e) {
			throw $e;
		}
	}
}
?>

