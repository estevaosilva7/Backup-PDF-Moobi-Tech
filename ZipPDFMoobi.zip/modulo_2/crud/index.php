<?php
header('Location: router.php');
