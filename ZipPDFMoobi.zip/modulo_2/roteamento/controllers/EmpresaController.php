<?php

class EmpresaController {
    public function index() {
        echo "Listagem de empresas";
    }

    public function save() {
        echo "Salvando empresa";
    }

    public function delete() {
        echo "Deletando empresa";
    }
}
