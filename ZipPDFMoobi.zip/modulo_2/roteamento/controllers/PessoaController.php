<?php

class PessoaController {
    public function index() {
        echo "Listagem de pessoas";
    }

    public function save() {
        echo "Salvando pessoa";
    }

    public function delete() {
        echo "Deletando pessoa";
    }
}
