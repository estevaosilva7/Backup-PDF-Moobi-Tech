<?php
header("HTTP 302 Found");
header("location: nova.php");
exit();
?>;
