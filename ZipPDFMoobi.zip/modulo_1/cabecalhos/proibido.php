<?php
header("HTTP 403 Forbidden");
echo 'Acesso proibido!';
exit();
?>;
