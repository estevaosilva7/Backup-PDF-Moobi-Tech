<?php
header("HTTP 301 - Moved Permanently");
header("location: nova.php");
exit();
?>;