<?php
header("HTTP 200 OK");
echo 'Você foi direcionado para nova.php';
exit();
?>;
