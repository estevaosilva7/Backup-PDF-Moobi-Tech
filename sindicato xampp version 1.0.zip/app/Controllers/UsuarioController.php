<?php
require_once __DIR__ . '/../Database/MoobiDatabaseHandler.php';
require_once __DIR__ . '/../Models/UsuarioModel.php';
require_once __DIR__ . '/../Session/CustomSessionHandler.php';
require_once __DIR__ . '/../Configuracoes/Url_Local.php';

/**
 * Controlador para gerenciar as ações relacionadas aos usuários.
 * Contém métodos para login, cadastro, listagem, exclusão. edição, atualização e logout de usuários.
 *
 * @author Estevão carlosestevao@moobitech.com.br
 */
class UsuarioController
{
    private $usuarioModel;

    /**
     * Construtor da classe UsuarioController.
     * Inicializa a instância do modelo de usuário com a conexão do banco de dados.
     *
     * @param $dbHandler Instância da classe MoobiDatabaseHandler.
     */
    public function __construct()
    {
        $dbHandler = new MoobiDatabaseHandler();
        $this->usuarioModel = new UsuarioModel($dbHandler);
    }

    /**
     * Exibe a tela inicial de login.
     */
    public function index()
    {
        require __DIR__ . '/../Views/Home/LoginView.php';
    }

    /**
     * Exibe a tela do dashboard para o usuário autenticado.
     * Redireciona para a view do dashboard do usuário quando.
     */
    public function dashboard()
    {
        require __DIR__ . '/../Views/Home/DashboardView.php';
    }

    /**
     * Realiza o login do usuário, validando o nome de usuário e senha.
     * Caso o login seja bem-sucedido, inicia uma sessão e redireciona para o dashboard.
     */
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $mNome = $_POST['nome'];
            $sSenha = $_POST['senha'];

            $nUsuario = $this->usuarioModel->verificarUsuario($mNome, $sSenha);

            if ($nUsuario) {
                CustomSessionHandler::set('usuario', $nUsuario);
                return require __DIR__ . '/../Views/Home/DashboardView.php';
            } else {
                echo "<p>Nome ou senha incorretos!</p>";
            }
        }

        require __DIR__ . '/../Views/Home/LoginView.php';
    }

    /**
     * Realiza o cadastro de um novo usuário no sistema.
     * Verifica se os dados são válidos e tenta salvar o novo usuário no banco.
     */
    public function cadastrar()
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem cadastrar usuários.</p>";
            return require __DIR__ . '/../Views/Home/DashboardView.php';
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $mNome = $_POST['nome'];
            $sSenha = $_POST['senha'];
            $mTipo = $_POST['tipo'];

            if (!preg_match('/^(?=.*[a-zA-Z])[a-zA-Z0-9]+$/', $mNome)) {
                echo "<p>O nome de usuário deve conter pelo menos uma letra e pode incluir apenas letras e números.</p>";
                return require __DIR__ . '/../Views/Usuario/CadastroUsuarioView.php';
            }

            if ($this->usuarioModel->cadastrarUsuario($mNome, $sSenha, $mTipo)) {
                echo "<p>Usuário cadastrado com sucesso!</p>";
            } else {
                echo "<p>ALERTA: Nome de usuário já em uso!</p>";
            }
        }

        require __DIR__ . '/../Views/Usuario/CadastroUsuarioView.php';
        exit();
    }

    /**
     * Lista todos os usuários cadastrados no sistema.
     * Exibe as informações dos usuários na view de listagem.
     */
    public function listar()
    {
        $usuarios = $this->usuarioModel->listarUsuarios();

        $usuarioLogado = CustomSessionHandler::get('usuario');
        $isAdmin = $usuarioLogado && $usuarioLogado['usu_Tipo'] == 'admin';

        require __DIR__ . '/../Views/Usuario/ListarUsuarioView.php';
        exit();
    }

    /**
     * Realiza a exclusão de um usuário do sistema, dado o ID.
     * Exibe mensagem de sucesso ou erro conforme o resultado da exclusão.
     *
     * @param int $id ID do usuário a ser deletado.
     */
    public function deletar($iId)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem excluir usuários.</p>";
            header('Location: /index.php/usuario/listar');
            exit();
        }
        if ($iId && is_numeric($iId)) {
            $bResultado = $this->usuarioModel->deletarUsuario($iId);
            if ($bResultado) {
                echo "<p>Usuário deletado com sucesso!</p>";
            } else {
                echo "<p>Erro ao deletar o usuário!</p>";
            }
        } else {
            echo "<p>ID inválido!</p>";
        }
        header('Location: ' . Config::pegarUrl() . 'usuario/listar');
        exit();
    }

    /**
     * Exibe o formulário de edição de usuário.
     * Realiza a verificação do ID e exibe as informações do usuário para edição.
     *
     * @param int $id ID do usuário a ser editado.
     */
    public function editar($id)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem editar usuários.</p>";
            header('Location: /index.php?path=usuario/listar');
            exit();
        }
        if ($id && is_numeric($id)) {
            $usuario = $this->usuarioModel->buscarUsuarioPorId($id);
            if (!$usuario) {
                echo "<p>Usuário não encontrado!</p>";
                header('Location: /index.php?path=usuario/listar');
                exit();
            }
            require __DIR__ . '/../Views/Usuario/EditarUsuarioView.php';

        } else {
            echo "<p>ID inválido!</p>";
            header('Location: /index.php?path=usuario/listar');
            exit();
        }
    }

    /**
     * Atualiza os dados de um usuário no sistema.
     * Verifica se o novo nome de usuário já existe e valida os dados antes de realizar a atualização.
     *
     * @param int $id ID do usuário a ser atualizado.
     */
    public function atualizar($id)
    {
        $usuarioLogado = CustomSessionHandler::get('usuario');
        if (!$usuarioLogado || $usuarioLogado['usu_Tipo'] != 'admin') {
            echo "<p>Acesso restrito. Somente administradores podem editar usuários.</p>";
            header('Location: /index.php/usuario/listar');
            exit();
        }
        if ($id && is_numeric($id)) {
            $mNome = $_POST['nome'];
            $mTipo = $_POST['tipo'];

            if ($this->usuarioModel->usuarioNomeExistente($mNome, $id)) {
                CustomSessionHandler::set('mensagem_erro', "O nome de usuário já está em uso.");
                header("Location: /index.php/usuario/editar&id=$id");
                exit();
            }
            if (!preg_match('/^(?=.*[a-zA-Z])[a-zA-Z0-9]+$/', $mNome)) {
                CustomSessionHandler::set('mensagem_erro', "O nome de usuário deve conter pelo menos uma letra e pode incluir apenas letras e números.");
                header("Location: /index.php/usuario/editar&id=$id");
                exit();
            }
            if ($this->usuarioModel->atualizarUsuario($id, $mNome, $mTipo)) {
                CustomSessionHandler::set('mensagem_sucesso', "Usuário atualizado com sucesso!");
                header('Location: ' . Config::pegarUrl() . "usuario/editar&id=$id");
                exit();
            } else {
                CustomSessionHandler::set('mensagem_erro', "Erro ao atualizar o usuário!");
                header("Location: /index.php/usuario/editar&id=$id");
                exit();
            }
        } else {
            CustomSessionHandler::set('mensagem_erro', "ID inválido!");
            header('Location: /index.php/usuario/listar');
            exit();
        }
    }

    /**
     * Realiza o logout do usuário, destruindo a sessão.
     * Redireciona o usuário para a página inicial.
     */
    public function logout()
    {
        CustomSessionHandler::destroy();
        header('Location: ' . Config::pegarUrl() . 'usuario/login');
        exit();
    }
}
?>